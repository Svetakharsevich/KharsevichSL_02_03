package com.bignerdranch.android.modul2

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton

class MainActivity : AppCompatActivity() {
    lateinit var login:EditText
    lateinit var password:EditText
    lateinit var appcompa: AppCompatButton
    lateinit var sharedPreference:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        login=findViewById(R.id.Login)
        password=findViewById(R.id.Password)
        appcompa=findViewById(R.id.ButtonSingIn)
        sharedPreference=getSharedPreferences("User", MODE_PRIVATE)

        appcompa.setOnClickListener{
            val inputlogin=login.text.toString().trim()
            val inputpassword=password.text.toString().trim()

            if(inputlogin.isEmpty()&&inputpassword.isEmpty()){
                showAlert("Введите логин и/или пароль")
            }
            else{
                if(sharedPreference.getString("login",null)==null||sharedPreference.getString("password",null)==null){
                    with(sharedPreference.edit()){
                        putString("login",inputlogin)
                        putString("password", inputpassword)
                        apply()
                    }
                    startActivity(Intent(this@MainActivity,MainActivity2::class.java))
                }
                else{
                    val savelogin=sharedPreference.getString("login",null)
                    val savepassword=sharedPreference.getString("password",null)
                    if(inputlogin==savelogin&&inputpassword==savepassword){
                        startActivity(Intent(this@MainActivity,MainActivity2::class.java))
                    }
                    else showAlert("Неверный логин и/или пароль")
                }
            }
            }
        }
        private fun showAlert(message: String){
            AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                    dialog, _ -> dialog.dismiss()
            }.show()
        }

}