package com.bignerdranch.android.modul2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton

class MainActivity3 : AppCompatActivity() {
    lateinit var itog:TextView
    lateinit var rezult:TextView
    lateinit var ButtonReturn:AppCompatButton
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        itog=findViewById(R.id.itog)
        rezult=findViewById(R.id.rezult)
        ButtonReturn=findViewById(R.id.ButtonReturn)
        var price=1000
        val itogMetr=intent.getIntExtra("loanTerm", 0)
        itog.text="количество метров: $itogMetr м."
        val i=intent.getIntExtra("sp", 0)
        var result=0.0
        when(i){
            0->{result=price*itogMetr*1.4}
            1->{result=price*itogMetr*1.0}
            2->{result=price*itogMetr*0.8}
            3->{result=price*itogMetr*1.1}
        }
        rezult.text="результат $result"

        ButtonReturn.setOnClickListener{
            startActivity(Intent(this@MainActivity3,MainActivity::class.java))
        }

    }
}