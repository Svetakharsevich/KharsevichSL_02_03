package com.bignerdranch.android.modul2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

class MainActivity2 : AppCompatActivity() {
    lateinit var ex: ImageButton
    lateinit var ButtonСalculate: Button
    lateinit var editText: EditText
    lateinit var spinner: Spinner
    lateinit var textview: TextView
    lateinit var rez:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
           var price=1000
            setContentView(R.layout.activity_main2)
            ex=findViewById(R.id.exit)
            spinner = findViewById(R.id.spinner)
            editText=findViewById(R.id.editText)
            ButtonСalculate=findViewById(R.id.ButtonСalculate)
            textview=findViewById(R.id.choice)
        val array= arrayOf("1. 1-о комнатная квартира",
            "2. 2-х комнатная квартира",
            "3. 3-x комнатная квартира",
            "4. Студия")
            val adapter=ArrayAdapter(this,android.R.layout.simple_spinner_item,array).also { adapter->
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            spinner.adapter = adapter
            
            ex.setOnClickListener {
                var intent= Intent(this, MainActivity::class.java)
                startActivity(intent)
            }

            ButtonСalculate.setOnClickListener{

                val sp=spinner.selectedItemPosition
                val itogMetr=editText.text.toString().toInt()
                var result=0.0
                when(sp){
                    0->{result=price*itogMetr*1.4}
                    1->{result=price*itogMetr*1.0}
                    2->{result=price*itogMetr*0.8}
                    3->{result=price*itogMetr*1.1}
                }
                rez.text="результат $result"



                if(editText.text.isEmpty()){
                    showAlert("Введите количество метров")
                }
                val loanTerm = editText.text.toString().toInt()
                var intent=Intent(this, MainActivity3::class.java)
                intent.putExtra("loanTerm", loanTerm)
                intent.putExtra("sp", sp)
                startActivity(intent)

            }
        }
        private fun showAlert(message: String){
            AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK") {
                    dialog, _ -> dialog.dismiss()
            }.show()
        }
    }
